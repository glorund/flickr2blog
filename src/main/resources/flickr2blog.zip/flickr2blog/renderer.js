



function showHtmlBox() {
    $('.floater').show();
}
function hideHtmlBox() {
    $('.floater').hide();
}

